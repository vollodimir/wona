<?php
/**
 * The template for displaying product content within loops
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.6.0
 */
//change--------------------------------------------------------------------------
//v magasini
	defined( 'ABSPATH' ) || exit;

	global $product;

	// Ensure visibility.
	if ( empty( $product ) || ! $product->is_visible() ) {
		return;
	}
	?>

			<div class="product">
              <div class="product__img">
                <a href="<?php echo get_permalink() ?>">
                  <img src="<?php
					if(has_post_thumbnail()){
						echo get_the_post_thumbnail_url($product->get_id()); 
					} else {
						echo  bloginfo('template_url').'/assets/img/shop/default.png';
					}
				 ?>" alt="product" />
                </a>
              </div>
              <div class="product__title"><?php echo $product->get_title(); ?></div>
              <div class="product__row">
                <div class="product__price"><?php 
						if ( $product->get_price() ) {
							echo get_woocommerce_currency_symbol();
							echo $product->get_price();
						}
				 ?></div>
					<?php
						if ( $product->get_stock_quantity() ) {
							echo '<div class="product__amount"> ' . wona_check_acf('amount', 'םיעבצ', true) . ' ' .  $product->get_stock_quantity()  . '</div>';
						}?>
              </div>
              <a href="<?php echo get_permalink() ?>" class="product__btn"><?php wona_check_acf('product_button', 'Details') ?></a>
            </div>
