<?php   get_header();
        the_post(); 
?>

    <main class="content">
      <div class="post">
        <h1><?php the_title(); ?></h1>
            <?php
                  if(get_the_post_thumbnail_url()){
                    ?>
                    <img src="<?php the_post_thumbnail_url();?>"><?php
                  }
                  the_content();
                ?>
      </div>
    </main>

<?php get_footer(); ?>