<?php get_header(); ?> 

    <main class="content">
          <div class="container">
            <?php 
              if ( have_posts() ) { ?>
                    <h1><?php single_cat_title( '', false ); ?></h1>
                      <?php
                        if ( category_description() ) { ?>
                          <p><?php echo category_description(); ?></p>
                        <?php } ?>
                        <?php
                          while ( have_posts() ) : the_post(); ?>
                            <?php get_template_part( 'template-parts/content/content'); ?>
                          <?php endwhile; 
                } else {
                    get_template_part( 'template-parts/content/content', 'none');  
                }
               the_posts_pagination(); ?>
          </div>
    </main>
<?php get_footer(); ?>