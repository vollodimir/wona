      <footer class="footer">Copyright © 2023 <a href="/"><?php bloginfo('name'); ?></a>. All rights reserved</footer>
    </div>
    <?php wp_footer(); ?>
  </body>
</html>