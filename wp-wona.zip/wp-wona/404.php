<?php get_header(); ?>

        <main class="content">
          <div class="container">
              <div class="post post--center">
                <h1>404</h2>
                <h3>Not Found!</h3>
              </div>
          </div>
        </main>

<?php get_footer(); ?>