<?php
    if ( ! defined( 'ABSPATH' ) ) {
        exit; // Exit if accessed directly
    }


    // register all menus
	function wona_register_all_menus() {
		register_nav_menus(array(
			'header_menu'       => 'Header menu',
			)
		);
	}
	add_action( 'init', 'wona_register_all_menus' );

    // header menu
	function wona_header_menu () {
		$args = array(
			'theme_location'    => 'header_menu',
			'menu_class'        => 'header__menu',
			'container'         => 'ul', 
			'echo'              =>  0 
		);
		$menu = wp_nav_menu( $args );
		$menu = preg_replace('~<ul class="sub-menu~', '<div class="menu-item-has-children__btn"></div><ul class="sub-menu', $menu );
		echo $menu;
	}
	


?>