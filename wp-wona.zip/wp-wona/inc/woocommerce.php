<?php

	// Woocommerce support
	function woocommerce_support() {
		add_theme_support('woocommerce');
		add_theme_support( 'wc-product-gallery-zoom' );
		add_theme_support( 'wc-product-gallery-lightbox' );
	}
	add_action( 'after_setup_theme', 'woocommerce_support' );
	
	

	remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );
	remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );
	
	//Remove default WooCommerce wrapper.
	remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
	remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );

	if ( ! function_exists( 'dev_woocommerce_wrapper_before' ) ) {
		function dev_woocommerce_wrapper_before() {
			?>
				<main class="shop">
					<div class="shop__container">
			<?php
		}
	}
	add_action( 'woocommerce_before_main_content', 'dev_woocommerce_wrapper_before' );

	if ( ! function_exists( 'dev_woocommerce_wrapper_after' ) ) {

		function dev_woocommerce_wrapper_after() {
			?>
					</div>
				</main>
			<?php
		}
	}
	add_action( 'woocommerce_after_main_content', 'dev_woocommerce_wrapper_after' );


	/// Add Read more
	remove_action( 'woocommerce_archive_description', 'woocommerce_taxonomy_archive_description', 10 );
	remove_action( 'woocommerce_archive_description', 'woocommerce_product_archive_description', 10 );
	add_action( 'woocommerce_archive_description', function($category){
    if (category_description($category->id)){
		echo '<div class="shop__description">' . category_description($category->id) . '</div>';
    	echo '<button class="shop__more">' . wona_check_acf('readmore_text', 'Read more', true) . '</button>';
	}
	} );


	// Product per page
	$default_posts_per_page = 6;
	add_filter( 'loop_shop_per_page', create_function( '$cols', 'return '.$default_posts_per_page.';' ));
	// Show all button
	if(isset( $_GET['showall']) ){ 
		add_filter( 'loop_shop_per_page', create_function( '$cols', 'return -1;' ) ); 
	} else {
		add_filter( 'loop_shop_per_page', create_function( '$cols', 'return '.$default_posts_per_page.';' ) );
	}


