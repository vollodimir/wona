<?php
    if ( ! defined( 'ABSPATH' ) ) {
        exit; // Exit if accessed directly
    }


    if ( !function_exists( 'amp_theme_support' ) ) {
        add_action( 'after_setup_theme', 'amp_theme_support' );

        function amp_theme_support() {
            add_theme_support('menus');
            add_theme_support('post-thumbnails');
            add_theme_support('title-tag');
            add_theme_support('custom-logo');
            add_theme_support( 'html5', array( 'search-form' ) );
        }
    }
?>