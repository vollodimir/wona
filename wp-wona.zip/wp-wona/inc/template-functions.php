<?php

    if ( ! defined( 'ABSPATH' ) ) {
        exit; // Exit if accessed directly
    }
 
    // check acf plugin activate 
	function wona_check_acf($fielf_acf, $echo_text, $to_params=false) {
		if (function_exists('get_field')){
			$home_id = get_option('page_on_front');

			if (get_field($fielf_acf, $home_id)){
				$page_id = $home_id;
			} else {
				$page_id = false;
			}
		}

		if(function_exists('get_field') && get_field($fielf_acf, $page_id)){
			if($to_params){
				return get_field($fielf_acf, $page_id); 
			} else {
				echo get_field($fielf_acf, $page_id);
			}
		 } else {
			if($to_params){
				return $echo_text; 
			} else {
				echo $echo_text;
			}
		}
	}

	
?>