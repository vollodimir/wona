<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package dev
 */

?>

	<div class="post">
		<h3><strong><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></strong></h3>
		<?php the_content(''); ?>
	</div>
