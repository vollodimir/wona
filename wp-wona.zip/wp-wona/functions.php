<?php

    // Connecting scripts and styles
    require get_template_directory() . '/inc/enqueue-scripts.php';

    // Add theme supports
    require get_template_directory() . '/inc/theme-support.php';

    // Custom functions
    require get_template_directory() . '/inc/template-functions.php';
    
    // Add menus
    require get_template_directory() . '/inc/theme-menu.php';
    

	if ( class_exists( 'WooCommerce' ) ) {
		require_once(get_template_directory() . '/inc/woocommerce.php');
        $woocommerce_on = true;
	}

?>