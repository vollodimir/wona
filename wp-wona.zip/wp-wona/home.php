<?php
/*
Template Name: Home Template
*/
?>

<?php get_header(); ?> 

    <main class="content">
            <?php
                  $args = array(
                    'posts_per_page' => -1,
                  );
                  $loop = new WP_Query($args);
                  while ( $loop->have_posts() ) {
                    $loop->the_post();
                ?>
                <div class="post">
                    <a href="<?php echo get_permalink() ?>"><h2> <?php the_title(); ?></h2></a>
                    <?php the_content(); ?>
                </div>
              <?php
                }
                the_posts_pagination();
            ?>
    </main>
 
<?php get_footer(); ?>