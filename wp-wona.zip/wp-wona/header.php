<!DOCTYPE html>
<html lang="<?php bloginfo('language'); ?>">
  <head>
    <meta charset="<?php bloginfo('charset'); ?>" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0" />
    <?php wp_head(); ?>
  </head>
  <body <?php body_class(); ?>>
    <div class="wrapper">
      <header class="header">
        <div class="header__body">
          <div class="slider">
            <div class="slider__list">
              


              <?php 
              //$home_id = get_option('page_on_front');
              $page_id = get_option('page_on_front');
              $images =  function_exists('get_field') ? get_field('header_galery', $page_id) : false;

              if( $images ) { ?>

                <?php foreach( $images as $image ) { ?>
                  <div class="slider__img">
                    <img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>" />
                  </div>
                <?php } ?>

              <?php } else { ?>

                      <div class="slider__img">
                        <img src="<?php bloginfo('template_url'); ?>/assets/img/sliders/slider_2.png" alt="slide 1" />
                      </div>
                      <div class="slider__img">
                        <img src="<?php bloginfo('template_url'); ?>/assets/img/sliders/slider_1.png" alt="slide 1" />
                      </div>

              <?php } ?>
              
 

            </div>
          </div>
          <nav class="header__navigation">
            <div class="header__blur"></div>
            <input class="header__input" type="checkbox" />
            <div class="header__lines"></div>
            <?php wona_header_menu (); ?>
            <!-- <ul class="header__menu">
              <li><a href="#">How it Works</a></li>
              <li class="menu-item-has-children">
                <a href="#">Products</a>
                <div class="menu-item-has-children__btn"></div>
                <ul class="sub-menu">
                  <li><a href="#">Stylematic Lipliner</a></li>
                  <li><a href="#">Waterproof Lipliner</a></li>
                  <li><a href="#">Lightweight Lip Powder</a></li>
                  <li class="menu-item-has-children">
                    <a href="#">Brushs</a>
                    <div class="menu-item-has-children__btn"></div>
                    <ul class="sub-menu">
                      <li><a href="#">Shading </a></li>
                      <li><a href="#">Makeup Set</a></li>
                      <li><a href="#">Eye Crease </a></li>
                      <li><a href="#">Brow </a></li>
                      <li><a href="#">Blending </a></li>
                      <li><a href="#">Eye </a></li>
                    </ul>
                  </li>
                  <li><a href="#">Hd Weightless Matte Lips</a></li>
                  <li><a href="#">Vitamin Bomb Serum</a></li>
                  <li><a href="#">Anti Age Eye Cream</a></li>
                </ul>
              </li>
              <li class="menu-item-has-children">
                <a href="#">Other Products</a>
                <div class="menu-item-has-children__btn"></div>
                <ul class="sub-menu">
                  <li><a href="#">Water Lip Stain</a></li>
                  <li><a href="#">Baby Showers</a></li>
                </ul>
              </li>
              <li><a href="#">Turn Around Time</a></li>
              <li><a href="#">About Us</a></li>
              <li><a href="#">FAQs</a></li>
              <li><a href="#">Contact Us</a></li>
            </ul> -->
          </nav>
        </div>
      </header>
      
      <?php 
      
     
      
     ?>
      <?php //echo var_dump($page_id); ?>